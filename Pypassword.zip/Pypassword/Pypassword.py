import customtkinter as ctk
from tkinter import messagebox
import secrets
import string
import os

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

class App(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Pypassword")
        self.geometry("450x300")
        self.resizable(False, False)
        
        # Define o ícone da janela (substitua 'icon.ico' pelo nome do seu arquivo)
        if os.path.exists(r"C:\Users\Carlos\Desktop\Pypassword\icon.ico"):
            self.iconbitmap(r"C:\Users\Carlos\Desktop\Pypassword\icon.ico")

        self.label = ctk.CTkLabel(self, text="Password Generator", font=("Roboto", 24))
        self.label.pack(pady=20)

        self.input_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.input_frame.pack(pady=10)

        self.entry_senha = ctk.CTkEntry(self.input_frame, width=250, justify="center", font=("Courier", 14))
        self.entry_senha.grid(row=0, column=0, padx=(0, 5))

        self.btn_copy = ctk.CTkButton(self.input_frame, text="Copy", width=60, font=("Roboto", 13), command=self.copy_password)
        self.btn_copy.grid(row=0, column=1)

        self.slider_label = ctk.CTkLabel(self, text="Length: 16", font=("Roboto", 12))
        self.slider_label.pack(pady=(10, 0))
        
        self.slider = ctk.CTkSlider(self, from_=8, to=32, command=self.update_label)
        self.slider.set(16)
        self.slider.pack(pady=10)

        self.btn_gerar = ctk.CTkButton(self, text="Generate Password", font=("Roboto", 14), command=self.gerar_senha)
        self.btn_gerar.pack(pady=20)

    def update_label(self, value):
        self.slider_label.configure(text=f"Length: {int(value)}")

    def gerar_senha(self):
        comprimento = int(self.slider.get())
        
        letras = string.ascii_letters
        digitos = string.digits
        simbolos = string.punctuation
        alfabeto_completo = letras + digitos + simbolos
        
        senha = [
            secrets.choice(string.ascii_uppercase),
            secrets.choice(string.ascii_lowercase),
            secrets.choice(string.digits),
            secrets.choice(string.punctuation),
        ]
        
        senha += [secrets.choice(alfabeto_completo) for _ in range(comprimento - 4)]
        senha_final = "".join(secrets.SystemRandom().sample(senha, len(senha)))
        
        self.entry_senha.delete(0, ctk.END)
        self.entry_senha.insert(0, senha_final)

    def copy_password(self):
        password = self.entry_senha.get()
        
        if not password:
            messagebox.showerror("Error", "Password not found, make sure you generated one first.")
            return
            
        self.clipboard_clear()
        self.clipboard_append(password)
        self.update()
        
        self.btn_copy.configure(text="Copied!", fg_color="green")
        self.after(1500, lambda: self.btn_copy.configure(text="Copy", fg_color=ctk.ThemeManager.theme["CTkButton"]["fg_color"]))

if __name__ == "__main__":
    app = App()
    app.mainloop()